# ALFS Limited — Web & Procurement Portal

> **Designed and Created by Mupenda Chama**  
> Official corporate website, safety procurement portal, and e-commerce store for **ALFS Limited** (Achilles Labour Force Services) — Lusaka & Chingola, Zambia.

---

## 🌟 Overview

**ALFS Limited** is Zambia's trusted standard for industrial safety gear, personal protective equipment (PPE), corporate workwear, and specialized labour workforce procurement.

This application provides a unified digital experience:
- **Corporate Website & Catalogue**: Comprehensive SABS-certified product showcase, downloadable compliance profiles, company certifications, and an interactive quotation builder with live PDF generation.
- **Online Safety Store (`/store`)**: High-performance mobile-first store featuring contractor discount tiers, category filtering, search, interactive product cards, a responsive mini-cart, and multi-province delivery calculations.
- **Labour Force Recruitment (`/labour`)**: Dedicated workforce supply portal connecting certified artisans, machine operators, safety officers, and general labour with industrial contractors across Zambia.

---

## ✨ Key Features

### 🛒 Online Safety Store
- **Product Catalogue**: Safety Footwear, High-Visibility Gear, Heavy Workwear, Head Protection, Hand Protection, and Eye & Ear Protection.
- **Contractor Pricing**: Dual pricing display (Normal vs Contractor rates) with dynamic savings indicators.
- **Interactive Shopping Cart**: Client-side cart with option matrix (sizes, colours, quantities), live subtotal updates, and instant slide-up mini-cart drawer.
- **Delivery Zone Matrix**: Automated regional fee calculation covering Lusaka Central, Lusaka Outskirts, Copperbelt (Kitwe, Ndola, Chingola), Southern, Eastern, Northern/Luapula, and North-Western provinces, plus free office depot pickup.
- **WhatsApp Integration**: Instant one-click quotation enquiry linking directly to official sales representatives with pre-filled product details.

### 💼 Corporate & Procurement Tools
- **Instant Quotation Builder**: Add catalogue items to a requisition list and generate professional, branded PDF quotes via `jspdf`.
- **Compliance & Credential Hub**: Direct access to PACRA, ZPPA, CEEC, and NAPSA compliance documents.
- **Labour Force Portal**: Direct application and deployment channels for skilled Zambian industrial workers.

---

## 🛠️ Tech Stack

- **Framework**: [React 19](https://react.dev/)
- **Bundler**: [Vite 6](https://vitejs.dev/)
- **Language**: [TypeScript](https://www.typescriptlang.org/)
- **Styling**: [Tailwind CSS v4](https://tailwindcss.com/)
- **Animation**: [Motion](https://motion.dev/)
- **Icons**: [Lucide React](https://lucide.dev/)
- **Document Export**: [jsPDF](https://github.com/parallax/jsPDF)

---

## 🚀 Getting Started

### Prerequisites
- Node.js (v18 or higher recommended)
- npm or bun

### Installation
```bash
# Clone the repository
git clone https://github.com/your-username/alfs-web.git

# Navigate into project directory
cd alfs-web

# Install dependencies
npm install
```

### Development
```bash
# Start local development server
npm run dev
```
The application will launch at `http://localhost:3000`.

### Production Build
```bash
# Build optimized production bundle
npm run build

# Preview production build locally
npm run preview
```

---

## 🎨 Design & Attribution

- **Creator & Lead Designer**: **Mupenda Chama**
- **Brand Palette**:
  - Deep Industrial Navy (`#1a2e4a` / `#21305b`)
  - Safety Crimson (`#C0392B` / `#e42321`)
  - Clean Slate / White backgrounds with rounded card architecture
- **Typography**: Poppins & Inter modern sans-serif

---

## 📄 License

All rights reserved. Designed and developed by **Mupenda Chama** for **ALFS Limited**.
