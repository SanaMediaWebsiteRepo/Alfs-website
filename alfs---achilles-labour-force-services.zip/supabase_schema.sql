-- Supabase Schema Setup for ALFS Labour Force Feature
-- Run these queries in your Supabase SQL Editor (https://supabase.com)

-- 1. Create alfs_labour_seekers Table
CREATE TABLE IF NOT EXISTS alfs_labour_seekers (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  trade TEXT NOT NULL, -- e.g. welder, driver, security guard
  region TEXT NOT NULL, -- Zambian province
  availability TEXT NOT NULL, -- full-time, part-time, contract
  phone TEXT NOT NULL,
  role TEXT DEFAULT 'seeker' NOT NULL,
  status TEXT DEFAULT 'active' NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- 2. Create alfs_labour_employers Table
CREATE TABLE IF NOT EXISTS alfs_labour_employers (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  company_name TEXT NOT NULL,
  field_of_work TEXT NOT NULL,
  region TEXT NOT NULL,
  contact_person TEXT NOT NULL,
  phone TEXT NOT NULL,
  role TEXT DEFAULT 'employer' NOT NULL,
  status TEXT DEFAULT 'active' NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- 3. Enable Row Level Security (RLS) on both tables
ALTER TABLE alfs_labour_seekers ENABLE ROW LEVEL SECURITY;
ALTER TABLE alfs_labour_employers ENABLE ROW LEVEL SECURITY;

-- 4. Create RLS Policies for alfs_labour_seekers
-- Policy: Anyone authenticated can read all active profiles
CREATE POLICY select_active_seekers ON alfs_labour_seekers
  FOR SELECT
  TO authenticated
  USING (status = 'active');

-- Policy: Users can only insert their own row
CREATE POLICY insert_own_seeker ON alfs_labour_seekers
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Policy: Users can only update their own row
CREATE POLICY update_own_seeker ON alfs_labour_seekers
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Policy: Admin email (to be replaced with VITE_ADMIN_EMAIL value in your Supabase or dynamic checklist)
-- Note: Replace 'admin@alfslimited.com' with your actual VITE_ADMIN_EMAIL
CREATE POLICY admin_all_seekers ON alfs_labour_seekers
  FOR ALL
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@alfslimited.com')
  WITH CHECK (auth.jwt() ->> 'email' = 'admin@alfslimited.com');


-- 5. Create RLS Policies for alfs_labour_employers
-- Policy: Anyone authenticated can read all active profiles
CREATE POLICY select_active_employers ON alfs_labour_employers
  FOR SELECT
  TO authenticated
  USING (status = 'active');

-- Policy: Users can only insert their own row
CREATE POLICY insert_own_employer ON alfs_labour_employers
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Policy: Users can only update their own row
CREATE POLICY update_own_employer ON alfs_labour_employers
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Policy: Admin email (to be replaced with VITE_ADMIN_EMAIL value in your Supabase or dynamic checklist)
-- Note: Replace 'admin@alfslimited.com' with your actual VITE_ADMIN_EMAIL
CREATE POLICY admin_all_employers ON alfs_labour_employers
  FOR ALL
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@alfslimited.com')
  WITH CHECK (auth.jwt() ->> 'email' = 'admin@alfslimited.com');

-- 6. Add auth_user_id to alfs_labour_seekers
ALTER TABLE alfs_labour_seekers ADD COLUMN IF NOT EXISTS auth_user_id UUID REFERENCES auth.users(id);
CREATE INDEX IF NOT EXISTS idx_alfs_labour_seekers_auth_user_id ON alfs_labour_seekers(auth_user_id);
NOTIFY pgrst, 'reload schema';

